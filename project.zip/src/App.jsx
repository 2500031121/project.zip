import { useState } from 'react';
import {
  ADMIN_CREDENTIALS,
  BLOOD_GROUPS,
  changeInventory,
  clearSession,
  getAccounts,
  getDonors,
  getInventory,
  getRequests,
  getSession,
  saveAccount,
  saveDonor,
  saveRequest,
  saveSession,
} from './storage.js';

function Link({ to, navigate, children, className }) {
  return (
    <a
      className={className}
      href={to}
      onClick={(event) => {
        event.preventDefault();
        navigate(to);
      }}
    >
      {children}
    </a>
  );
}

function Header({ session, navigate, onLogout }) {
  return (
    <nav className="topbar">
      <Link to={session?.role === 'admin' ? '/admin' : session ? '/user' : '/'} navigate={navigate} className="brand">
        <span className="brand-mark" aria-hidden="true">+</span>
        <span>Blood Donation</span>
      </Link>
      <div className="nav-links">
        {session ? (
          <>
            <Link to={session.role === 'admin' ? '/admin' : '/user'} navigate={navigate}>
              {session.role === 'admin' ? 'Admin' : 'Home'}
            </Link>
            {session.role === 'user' && <Link to="/user/donor" navigate={navigate}>Donate</Link>}
            {session.role === 'user' && <Link to="/user/request" navigate={navigate}>Request blood</Link>}
            <Link to="/inventory" navigate={navigate}>Inventory</Link>
            <button type="button" className="nav-button" onClick={onLogout}>Log out</button>
          </>
        ) : (
          <>
            <Link to="/" navigate={navigate}>Login</Link>
            <Link to="/signup" navigate={navigate}>Sign up</Link>
          </>
        )}
      </div>
    </nav>
  );
}

function PageTitle({ eyebrow, children, detail }) {
  return (
    <header className="page-heading">
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h1>{children}</h1>
      {detail && <p className="page-detail">{detail}</p>}
    </header>
  );
}

function BloodGroupSelect({ required = true, id = 'blood', name = 'blood' }) {
  return (
    <select id={id} name={name} defaultValue="" required={required}>
      <option value="">Select group</option>
      {BLOOD_GROUPS.map((group) => (
        <option value={group.value} key={group.value}>{group.label}</option>
      ))}
    </select>
  );
}

function Login({ navigate, onLogin }) {
  const [role, setRole] = useState('user');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function submit(event) {
    event.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (role === 'admin') {
      if (normalizedEmail !== ADMIN_CREDENTIALS.email || password !== ADMIN_CREDENTIALS.password) {
        setError('Admin email or password is incorrect.');
        return;
      }
      onLogin({ name: 'Administrator', email: normalizedEmail, role: 'admin' });
      navigate('/admin');
      return;
    }

    const account = getAccounts().find(
      (item) => item.email === normalizedEmail && item.password === password,
    );
    if (!account) {
      setError('Account not found or password is incorrect.');
      return;
    }
    onLogin({ name: account.name, email: account.email, role: 'user' });
    navigate('/user');
  }

  return (
    <>
      <PageTitle eyebrow="Blood bank portal">Welcome back</PageTitle>
      <section className="form-panel auth-panel">
        <div className="role-switch" role="group" aria-label="Login role">
          <button type="button" className={role === 'user' ? 'selected' : ''} onClick={() => { setRole('user'); setError(''); }}>User</button>
          <button type="button" className={role === 'admin' ? 'selected' : ''} onClick={() => { setRole('admin'); setError(''); }}>Admin</button>
        </div>
        <form onSubmit={submit}>
          <label htmlFor="login-email">Email</label>
          <input id="login-email" type="email" autoComplete="username" placeholder="you@example.com" value={email} onChange={(event) => setEmail(event.target.value)} required />
          <label htmlFor="login-password">Password</label>
          <input id="login-password" type="password" autoComplete="current-password" placeholder="Enter your password" value={password} onChange={(event) => setPassword(event.target.value)} required />
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="primary-button" type="submit">Login as {role}</button>
        </form>
        {role === 'admin' && <p className="form-note">Demo admin: admin@bloodbank.local / admin123</p>}
        <p className="form-note">New to the blood bank? <Link to="/signup" navigate={navigate}>Create a user account</Link></p>
        <p className="storage-note">Demo application. Accounts and records are saved in this browser only.</p>
      </section>
    </>
  );
}

function Signup({ navigate, onLogin }) {
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [error, setError] = useState('');

  function submit(event) {
    event.preventDefault();
    const normalizedEmail = email.trim().toLowerCase();
    if (normalizedEmail === ADMIN_CREDENTIALS.email || getAccounts().some((account) => account.email === normalizedEmail)) {
      setError('An account with this email already exists.');
      return;
    }
    const account = { name: name.trim(), email: normalizedEmail, password };
    saveAccount(account);
    onLogin({ name: account.name, email: account.email, role: 'user' });
    navigate('/user');
  }

  return (
    <>
      <PageTitle eyebrow="User module">Create your account</PageTitle>
      <section className="form-panel auth-panel">
        <form onSubmit={submit}>
          <label htmlFor="signup-name">Full name</label>
          <input id="signup-name" value={name} onChange={(event) => setName(event.target.value)} autoComplete="name" placeholder="Your name" required />
          <label htmlFor="signup-email">Email</label>
          <input id="signup-email" type="email" value={email} onChange={(event) => setEmail(event.target.value)} autoComplete="email" placeholder="you@example.com" required />
          <label htmlFor="signup-password">Password</label>
          <input id="signup-password" type="password" value={password} onChange={(event) => setPassword(event.target.value)} autoComplete="new-password" minLength="6" placeholder="At least 6 characters" required />
          {error && <p className="form-error" role="alert">{error}</p>}
          <button className="primary-button" type="submit">Create account</button>
        </form>
        <p className="form-note">Already registered? <Link to="/" navigate={navigate}>Login</Link></p>
        <p className="storage-note">Demo application. Your account is stored in this browser only.</p>
      </section>
    </>
  );
}

function UserHome({ session, navigate }) {
  const donors = getDonors().filter((donor) => donor.userEmail === session.email);
  const requests = getRequests().filter((request) => request.userEmail === session.email);
  return (
    <>
      <PageTitle eyebrow="User module" detail="Choose a service to get started.">Hello, {session.name}</PageTitle>
      <section className="dashboard-grid">
        <button className="action-tile" onClick={() => navigate('/user/donor')}>
          <span className="tile-icon">+</span><span className="tile-title">Donate blood</span><span className="tile-copy">Register a donation and add to local inventory.</span>
        </button>
        <button className="action-tile" onClick={() => navigate('/user/request')}>
          <span className="tile-icon">↗</span><span className="tile-title">Request blood</span><span className="tile-copy">Find a matching donor in your area.</span>
        </button>
        <button className="action-tile" onClick={() => navigate('/inventory')}>
          <span className="tile-icon">▤</span><span className="tile-title">View inventory</span><span className="tile-copy">Check available units by blood group.</span>
        </button>
      </section>
      <section className="summary-strip" aria-label="Your activity">
        <div><strong>{donors.length}</strong><span>Donations registered</span></div>
        <div><strong>{requests.length}</strong><span>Requests submitted</span></div>
        <div><strong>{getDonors().length}</strong><span>Community donors</span></div>
      </section>
    </>
  );
}

function DonorRegistration({ session, onChange }) {
  const [message, setMessage] = useState('');
  function submit(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const blood = data.get('blood');
    const inventory = getInventory();
    inventory[blood] += 1;
    saveDonor({
      name: data.get('name').trim(),
      age: Number(data.get('age')),
      gender: data.get('gender'),
      blood,
      state: data.get('state').trim().toLowerCase(),
      city: data.get('city').trim().toLowerCase(),
      phone: data.get('phone').trim(),
      userEmail: session.email,
      createdAt: new Date().toISOString(),
    });
    localStorage.setItem('bloodbank.inventory', JSON.stringify(inventory));
    event.currentTarget.reset();
    setMessage('Donor registered. One unit has been added to the inventory.');
    onChange();
  }

  return (
    <>
      <PageTitle eyebrow="User module">Donor registration</PageTitle>
      <section className="form-panel">
        <form onSubmit={submit}>
          <label htmlFor="donor-name">Name</label><input id="donor-name" name="name" placeholder="Enter your name" required />
          <label htmlFor="donor-age">Age</label><input id="donor-age" name="age" type="number" min="18" max="100" placeholder="Enter your age" required />
          <label htmlFor="donor-gender">Gender</label>
          <select id="donor-gender" name="gender" defaultValue="Male"><option>Male</option><option>Female</option><option>Other</option></select>
          <label htmlFor="donor-blood">Blood group</label><BloodGroupSelect id="donor-blood" />
          <label htmlFor="donor-state">State</label><input id="donor-state" name="state" placeholder="Enter your state" required />
          <label htmlFor="donor-city">City</label><input id="donor-city" name="city" placeholder="Enter your city" required />
          <label htmlFor="donor-phone">Phone number</label><input id="donor-phone" name="phone" type="tel" placeholder="Enter your phone number" required />
          {message && <p className="form-success" role="status">{message}</p>}
          <button className="primary-button" type="submit">Register donor</button>
        </form>
      </section>
    </>
  );
}

function BloodRequest({ session, onChange }) {
  const [message, setMessage] = useState('');
  const [error, setError] = useState(false);
  function submit(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const blood = data.get('blood');
    const city = data.get('city').trim().toLowerCase();
    const state = data.get('state').trim().toLowerCase();
    const units = Number(data.get('units'));
    const matchingDonors = getDonors().filter((donor) => donor.blood === blood && donor.state === state && donor.city === city);
    const inventory = getInventory();

    if (matchingDonors.length < units) {
      setError(true);
      setMessage(matchingDonors.length === 0 ? 'No matching donor found in this city and state.' : 'There are not enough matching donors for this request.');
      return;
    }
    if (inventory[blood] < units) {
      setError(true);
      setMessage('There are not enough units available in the inventory.');
      return;
    }

    inventory[blood] -= units;
    localStorage.setItem('bloodbank.inventory', JSON.stringify(inventory));
    saveRequest({
      patient: data.get('patient').trim(),
      age: Number(data.get('age')),
      blood,
      hospital: data.get('hospital').trim(),
      state,
      city,
      phone: data.get('phone').trim(),
      units,
      userEmail: session.email,
      createdAt: new Date().toISOString(),
      status: 'Fulfilled',
    });
    event.currentTarget.reset();
    setError(false);
    setMessage('Matching donors found. The blood request was fulfilled.');
    onChange();
  }

  return (
    <>
      <PageTitle eyebrow="User module">Blood request</PageTitle>
      <section className="form-panel">
        <form onSubmit={submit}>
          <label htmlFor="patient">Patient name</label><input id="patient" name="patient" placeholder="Enter patient name" required />
          <label htmlFor="patient-age">Age</label><input id="patient-age" name="age" type="number" min="0" max="120" placeholder="Enter age" required />
          <label htmlFor="request-blood">Blood group required</label><BloodGroupSelect id="request-blood" />
          <label htmlFor="hospital">Hospital name</label><input id="hospital" name="hospital" placeholder="Enter hospital name" required />
          <label htmlFor="request-state">State</label><input id="request-state" name="state" placeholder="Enter state" required />
          <label htmlFor="request-city">City</label><input id="request-city" name="city" placeholder="Enter city" required />
          <label htmlFor="request-phone">Phone number</label><input id="request-phone" name="phone" type="tel" placeholder="Enter phone number" required />
          <label htmlFor="units">Blood units required</label><input id="units" name="units" type="number" min="1" max="20" placeholder="Enter units" required />
          {message && <p className={error ? 'form-error' : 'form-success'} role={error ? 'alert' : 'status'}>{message}</p>}
          <button className="primary-button" type="submit">Submit request</button>
        </form>
      </section>
    </>
  );
}

function Inventory({ session }) {
  const inventory = getInventory();
  return (
    <>
      <PageTitle eyebrow={session?.role === 'admin' ? 'Admin module' : 'User module'}>Blood inventory</PageTitle>
      <section className="table-wrap">
        <table>
          <thead><tr><th>Blood group</th><th>Available units</th></tr></thead>
          <tbody>{BLOOD_GROUPS.map((group) => (
            <tr key={group.value}><td><span className="blood-type">{group.label}</span></td><td>{inventory[group.value]}</td></tr>
          ))}</tbody>
        </table>
      </section>
    </>
  );
}

function AdminDashboard({ onChange }) {
  const [message, setMessage] = useState('');
  const [donors, setDonors] = useState(getDonors());
  const [requests, setRequests] = useState(getRequests());
  const [inventory, setInventoryView] = useState(getInventory());

  function adjust(event) {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const delta = Number(data.get('direction')) * Number(data.get('units'));
    const changed = changeInventory(data.get('blood'), delta);
    if (!changed) {
      setMessage('Inventory cannot be reduced below zero.');
      return;
    }
    setMessage('Inventory updated.');
    setInventoryView(getInventory());
    onChange();
  }

  function refresh() {
    setDonors(getDonors());
    setRequests(getRequests());
    setInventoryView(getInventory());
  }

  return (
    <>
      <PageTitle eyebrow="Admin module" detail="Manage inventory and review blood bank activity.">Administration</PageTitle>
      <div className="admin-stats">
        <div><span>Registered donors</span><strong>{donors.length}</strong></div>
        <div><span>Blood requests</span><strong>{requests.length}</strong></div>
        <div><span>Total available units</span><strong>{Object.values(inventory).reduce((sum, units) => sum + units, 0)}</strong></div>
      </div>
      <section className="admin-section">
        <div className="section-heading"><h2>Manage inventory</h2><button className="text-button" onClick={refresh}>Refresh records</button></div>
        <form className="inventory-form" onSubmit={adjust}>
          <label htmlFor="admin-blood">Blood group</label>
          <select id="admin-blood" name="blood" defaultValue={BLOOD_GROUPS[0].value}>{BLOOD_GROUPS.map((group) => <option value={group.value} key={group.value}>{group.label}</option>)}</select>
          <label htmlFor="direction">Action</label>
          <select id="direction" name="direction" defaultValue="1"><option value="1">Add units</option><option value="-1">Remove units</option></select>
          <label htmlFor="admin-units">Units</label><input id="admin-units" name="units" type="number" min="1" max="1000" defaultValue="1" required />
          <button className="primary-button" type="submit">Update stock</button>
        </form>
        {message && <p className="form-success" role="status">{message}</p>}
      </section>
      <section className="admin-section">
        <div className="section-heading"><h2>Donor records</h2><span className="count-label">{donors.length} total</span></div>
        <div className="table-wrap compact-table"><table>
          <thead><tr><th>Name</th><th>Blood group</th><th>Location</th><th>Contact</th></tr></thead>
          <tbody>{donors.length ? donors.map((donor, index) => <tr key={`${donor.userEmail}-${donor.createdAt}-${index}`}><td>{donor.name}</td><td>{BLOOD_GROUPS.find((group) => group.value === donor.blood)?.label}</td><td>{donor.city}, {donor.state}</td><td>{donor.phone}</td></tr>) : <tr><td colSpan="4" className="empty-cell">No donor records yet.</td></tr>}</tbody>
        </table></div>
      </section>
      <section className="admin-section">
        <div className="section-heading"><h2>Blood requests</h2><span className="count-label">{requests.length} total</span></div>
        <div className="table-wrap compact-table"><table>
          <thead><tr><th>Patient</th><th>Blood group</th><th>Units</th><th>Hospital</th><th>Status</th></tr></thead>
          <tbody>{requests.length ? requests.map((request, index) => <tr key={`${request.userEmail}-${request.createdAt}-${index}`}><td>{request.patient}</td><td>{BLOOD_GROUPS.find((group) => group.value === request.blood)?.label}</td><td>{request.units}</td><td>{request.hospital}</td><td>{request.status}</td></tr>) : <tr><td colSpan="5" className="empty-cell">No requests yet.</td></tr>}</tbody>
        </table></div>
      </section>
    </>
  );
}

export default function App() {
  const [path, setPath] = useState(window.location.pathname);
  const [session, setSession] = useState(getSession);
  const [, setRevision] = useState(0);

  function navigate(to) {
    window.history.pushState({}, '', to);
    setPath(to);
    window.scrollTo(0, 0);
  }

  function update() {
    setRevision((revision) => revision + 1);
  }

  function login(nextSession) {
    saveSession(nextSession);
    setSession(nextSession);
  }

  function logout() {
    clearSession();
    setSession(null);
    navigate('/');
  }

  window.onpopstate = () => setPath(window.location.pathname);

  let page;
  if (path === '/signup') {
    page = <Signup navigate={navigate} onLogin={login} />;
  } else if (path === '/admin') {
    page = session?.role === 'admin' ? <AdminDashboard onChange={update} /> : <AccessDenied navigate={navigate} />;
  } else if (path === '/inventory') {
    page = <Inventory session={session} />;
  } else if (path === '/user/donor') {
    page = session?.role === 'user' ? <DonorRegistration session={session} onChange={update} /> : <AccessDenied navigate={navigate} />;
  } else if (path === '/user/request') {
    page = session?.role === 'user' ? <BloodRequest session={session} onChange={update} /> : <AccessDenied navigate={navigate} />;
  } else if (path === '/user') {
    page = session?.role === 'user' ? <UserHome session={session} navigate={navigate} /> : <AccessDenied navigate={navigate} />;
  } else {
    page = session?.role === 'admin'
      ? <AdminDashboard onChange={update} />
      : session ? <UserHome session={session} navigate={navigate} /> : <Login navigate={navigate} onLogin={login} />;
  }

  return (
    <>
      <Header session={session} navigate={navigate} onLogout={logout} />
      <main className="page-shell">{page}</main>
      <footer className="site-footer">Blood Donation <span>·</span> Local demo</footer>
    </>
  );
}

function AccessDenied({ navigate, destination = '/' }) {
  return (
    <section className="message-panel">
      <PageTitle eyebrow="Access required">Please log in</PageTitle>
      <p>This module is available to an authenticated account with the correct role.</p>
      <button className="primary-button" onClick={() => navigate(destination)}>Continue</button>
    </section>
  );
}