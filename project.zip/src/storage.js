export const BLOOD_GROUPS = [
  { value: 'Apositive', label: 'A+' },
  { value: 'Anegative', label: 'A-' },
  { value: 'Bpositive', label: 'B+' },
  { value: 'Bnegative', label: 'B-' },
  { value: 'ABpositive', label: 'AB+' },
  { value: 'ABnegative', label: 'AB-' },
  { value: 'Opositive', label: 'O+' },
  { value: 'Onegative', label: 'O-' },
];

export const ADMIN_CREDENTIALS = {
  email: 'admin@bloodbank.local',
  password: 'admin123',
};

const KEYS = {
  accounts: 'bloodbank.accounts',
  session: 'bloodbank.session',
  donors: 'donors',
  requests: 'bloodbank.requests',
  inventory: 'bloodbank.inventory',
};

function read(key, fallback) {
  try {
    const stored = localStorage.getItem(key);
    return stored ? JSON.parse(stored) : fallback;
  } catch {
    return fallback;
  }
}

function write(key, value) {
  localStorage.setItem(key, JSON.stringify(value));
}

export function getAccounts() {
  return read(KEYS.accounts, []);
}

export function saveAccount(account) {
  const accounts = getAccounts();
  accounts.push(account);
  write(KEYS.accounts, accounts);
}

export function getSession() {
  return read(KEYS.session, null);
}

export function saveSession(session) {
  write(KEYS.session, session);
}

export function clearSession() {
  localStorage.removeItem(KEYS.session);
}

export function getDonors() {
  return read(KEYS.donors, []);
}

export function saveDonor(donor) {
  write(KEYS.donors, [...getDonors(), donor]);
}

export function getRequests() {
  return read(KEYS.requests, []);
}

export function saveRequest(request) {
  write(KEYS.requests, [...getRequests(), request]);
}

export function getInventory() {
  const inventory = read(KEYS.inventory, {});
  return Object.fromEntries(
    BLOOD_GROUPS.map(({ value }) => [
      value,
      Number(inventory[value] ?? localStorage.getItem(value) ?? 0),
    ]),
  );
}

export function setInventory(inventory) {
  write(KEYS.inventory, inventory);
}

export function changeInventory(group, delta) {
  const inventory = getInventory();
  const nextCount = inventory[group] + delta;
  if (nextCount < 0) return false;
  inventory[group] = nextCount;
  setInventory(inventory);
  return true;
}